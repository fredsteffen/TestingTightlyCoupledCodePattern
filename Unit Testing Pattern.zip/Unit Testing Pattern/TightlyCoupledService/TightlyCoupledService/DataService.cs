﻿using System;
using System.Collections.Generic;
using System.Linq;
using TightlyCoupledService.Entities;

namespace TightlyCoupledService
{
    public class DataService
    {
        public DataService()
        {

        }

        /// <summary>
        /// Cannot unit test this method, as it creates its data source inside the method. No way to inject mock data.
        /// </summary>
        /// <param name="year"></param>
        /// <returns></returns>
        public List<Vehicle> GetVehiclesByYearTightlyCoupled(int year)
        {
            var dataSrc = new DataSource();
            return dataSrc.Vehicles.Where(v => v.Year == year).ToList();
        }

        /// <summary>
        /// This still sucks, but it's unit testable. The data source is moved to a new virtual method. To replace the data source
        /// we create a new sub-class of this class. We override the GetDataSource method with one of our own that takes
        /// fake data.
        /// </summary>
        /// <param name="year"></param>
        /// <returns></returns>
        public List<Vehicle> GetVehiclesByYearTestable(int year)
        {
            var dataSrc = GetDataSource();
            return dataSrc.Vehicles.Where(v => v.Year == year).ToList();
        }

        protected virtual DataSource GetDataSource()
        {
            return new DataSource();
        }
    }
}
