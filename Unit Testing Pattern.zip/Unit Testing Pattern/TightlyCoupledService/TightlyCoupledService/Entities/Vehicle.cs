﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace TightlyCoupledService.Entities
{
    public class Vehicle
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public Color Color { get; set; }
    }
}
