﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using TightlyCoupledService.Entities;

namespace TightlyCoupledService
{
    public class DataSource
    {
        private static List<Vehicle> _vehicles = new List<Vehicle>()
        {
            new Vehicle() { Color = Color.AliceBlue, Make = "Volkswagen", Model = "Beetle", Year = 1970 },
            new Vehicle() { Color = Color.Purple, Make = "Toyota", Model = "Tacoma", Year = 1982 },
            new Vehicle() { Color = Color.Olive, Make = "Audi", Model = "2", Year = 1990 },
            new Vehicle() { Color = Color.DarkGreen, Make = "Mazda", Model = "6", Year = 2001 },
            new Vehicle() { Color = Color.Aqua, Make = "Volkswagen", Model = "Jetta", Year = 2011 },
            new Vehicle() { Color = Color.Chocolate, Make = "Tesla", Model = "S", Year = 2013 },
            new Vehicle() { Color = Color.DarkRed, Make = "Tesla", Model = "3", Year = 2020 }
        };
        public virtual IQueryable<Vehicle> Vehicles { get { return _vehicles.AsQueryable(); } }

    }
}
