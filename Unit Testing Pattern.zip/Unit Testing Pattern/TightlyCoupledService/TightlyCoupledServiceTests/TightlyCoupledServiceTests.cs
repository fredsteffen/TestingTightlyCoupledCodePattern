using Moq;
using Moq.Protected;
using NUnit.Framework;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using TightlyCoupledService;
using TightlyCoupledService.Entities;

namespace TightlyCoupledServiceTests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void ReplaceDataUsingADerivedClass()
        {
            var svc = new DataServiceFixture();
            var result = svc.GetVehiclesByYearTestable(1908);
            Assert.That(result.Count, Is.EqualTo(1));
            var firstVehicle = result.First();
            Assert.That(firstVehicle.Year, Is.EqualTo(1908));
        }

        [Test]
        public void ReplaceDataUsingMoq()
        {
            // Uses moq to override the protected method. 
            // I'm cheating here. I could have created a Mock DataSource with the property faked.
            // But I had the DataSourceFixture here already.
            var svcMock = new Mock<DataService>();
            svcMock.Protected().Setup<DataSource>("GetDataSource").Returns(new DataSourceFixture());
            var svc = svcMock.Object;

            var result = svc.GetVehiclesByYearTestable(1908);
            Assert.That(result.Count, Is.EqualTo(1));
            var firstVehicle = result.First();
            Assert.That(firstVehicle.Year, Is.EqualTo(1908));
        }
    }

    public class DataServiceFixture : DataService
    {
        protected override DataSource GetDataSource()
        {
            return new DataSourceFixture();
        }
    }

    public class DataSourceFixture : DataSource
    {
        private List<Vehicle> _vehicles = new List<Vehicle>()
        {
            new Vehicle() { Color = Color.Black, Make = "Ford", Model = "T", Year = 1908 }
        };
        public override IQueryable<Vehicle> Vehicles => _vehicles.AsQueryable();
    }
}